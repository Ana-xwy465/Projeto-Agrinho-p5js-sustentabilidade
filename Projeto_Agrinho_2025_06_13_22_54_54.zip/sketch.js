// Configura o canvas
function setup() {
  createCanvas(800, 600);
  noLoop(); // Desenha apenas uma vez
}

// Função principal de desenho
function draw() {
  background(135, 206, 235); // Céu azul claro
  text("Para um mundo mais limpo, é nescessario mentes limpas!", 300, 100);
  text("Faça sua parte,cuidando do que é seu!", 350, 150);
  drawSun(); //Sol
  drawGrass(); //Grama
  drawBuildings(); //Prédios
  drawTrees(); //Árvores
  drawRoad(); //Rua
  drawCars(); //Carros
  drawWindTurbines(); //Turbinas eólicas
}

// 🌞 Sol brilhante no céu
function drawSun() {
  fill(255, 223, 0);
  noStroke();
  ellipse(700, 100, 100, 100);
}

// 🌿 Grama do chão
function drawGrass() {
  fill(60, 179, 113); // Verde vivo
  noStroke();
  rect(0, 400, width, 200);
}

// 🏢 Conjunto de prédios
function drawBuildings() {
  let colors = ["#FFADAD", "#FFD6A5", "#FDFFB6", "#CAFFBF", "#9BF6FF"];
  for (let i = 0; i < 5; i++) {
    fill(colors[i]);
    rect(100 + i * 120, 250 - i * 10, 80, 150 + i * 10); // Prédios com alturas variadas
    fill(255);
    for (let y = 260; y < 400; y += 30) {
      rect(110 + i * 120, y - i * 10, 20, 20); // Janelas
      rect(150 + i * 120, y - i * 10, 20, 20);
    }
  }
}

// 🌳 Árvores
function drawTrees() {
  for (let i = 0; i < 6; i++) {
    let x = 50 + i * 130;
    fill(101, 67, 33); // Tronco
    rect(x, 350, 20, 50);
    fill(34, 139, 34); // Copa
    ellipse(x + 10, 340, 60, 60);
  }
}

// 🛣️ Estrada cinza escura com faixa amarela
function drawRoad() {
  fill(50);
  rect(0, 450, width, 100);
  stroke(255, 215, 0);
  strokeWeight(4);
  for (let x = 0; x < width; x += 40) {
    line(x, 500, x + 20, 500); // Faixa central tracejada
  }
  noStroke();
}

// 🚗 Carros coloridos
function drawCars() {
  let carColors = ["#FF69B4", "#00CED1", "#FFA500"];
  for (let i = 0; i < 3; i++) {
    let x = 100 + i * 200;
    fill(carColors[i]);
    rect(x, 470, 60, 30); // Corpo
    fill(0);
    ellipse(x + 10, 500, 15, 15); // Roda esquerda
    ellipse(x + 50, 500, 15, 15); // Roda direita
  }
}

// 🌬️ Turbinas eólicas brancas no fundo
function drawWindTurbines() {
  for (let i = 0; i < 3; i++) {
    let x = 100 + i * 200;
    stroke(200);
    strokeWeight(4);
    line(x, 200, x, 300); // Mastro
    line(x, 200, x - 20, 180); // Hélice 1
    line(x, 200, x + 20, 180); // Hélice 2
    line(x, 200, x, 170); // Hélice 3
  }
}
//sites usados para apoio:Referencias do p5js, Chatgpt,outros.
//criadora:Ana Clara D. M.
